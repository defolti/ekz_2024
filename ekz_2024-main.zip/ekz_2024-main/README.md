# ekz_2024
всем 50 баллов и 5 аморетто

ПРИМЕРЫ СТАРЫХ КОДОВ:
LoginForm.txt, MainMenuForm.txt, class buffer.txt, class db.txt

ФОТО:
er-диаграмма

БД:
база данных код, de233dfd20100aab.sql

ПРИЛОЖУХА:
algoritm work
